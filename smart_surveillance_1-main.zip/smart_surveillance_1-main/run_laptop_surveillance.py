import cv2    
import numpy as np
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input

# --- Configuration ---
MODEL_PATH = "activity_multiclass_model.h5"
CLASS_NAMES_PATH = "class_names.txt"
IMG_SIZE = (128, 128) # MATCH THIS TO TRAINING SIZE

# Define which actions are "Normal"
NORMAL_ACTIONS = ["Normal_Sitting", "Normal_Standing", "Normal_Walking"]

# --- Load Model & Classes ---
print("⏳ Loading model...")
model = load_model(MODEL_PATH)

print("⏳ Loading labels...")
with open(CLASS_NAMES_PATH, "r") as f:
    class_names = f.read().splitlines()

print(f"✅ Model loaded. Classes: {class_names}")

# --- Camera Setup ---
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("❌ Error: Could not open camera.")
    exit()

print("✅ Camera started. Press 'q' to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        print("❌ Failed to capture frame.")
        break

    # 1. Preprocess the frame (MUST MATCH TRAINING)
    resized = cv2.resize(frame, IMG_SIZE)
    array = img_to_array(resized)
    # Use the specific MobileNet preprocessor (scales to -1 to 1)
    input_image = np.expand_dims(preprocess_input(array), axis=0)

    # 2. Predict
    predictions = model.predict(input_image, verbose=0)
    predicted_index = np.argmax(predictions)
    confidence = np.max(predictions)
    label = class_names[predicted_index]

    # 3. Determine Color & Status
    if label in NORMAL_ACTIONS:
        status_text = f"Status: {label} ({confidence*100:.1f}%)"
        color = (0, 255, 0) # Green
    else:
        status_text = f"WARNING: {label} ({confidence*100:.1f}%)"
        color = (0, 0, 255) # Red

    # 4. Display on Screen
    cv2.rectangle(frame, (0, 0), (frame.shape[1], 60), (0, 0, 0), -1) 
    cv2.putText(frame, status_text, (20, 40),
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

    cv2.imshow("Smart Surveillance - Multi-Class", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Cleanup
cap.release()
cv2.destroyAllWindows()
print("🛑 System stopped.")