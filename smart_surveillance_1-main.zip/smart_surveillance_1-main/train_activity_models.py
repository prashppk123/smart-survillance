import tensorflow as tf
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D, Dropout
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.applications import MobileNetV2
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
import os

# --- Constants ---
# Increased size to 128x128 (Better for seeing action details than 64x64)
IMG_SIZE = (128, 128) 
BATCH_SIZE = 32
DATASET_DIR = 'datasets'

# --- 1. Robust Data Augmentation ---
# This creates fake variations so your 50 images look like 500 to the model
train_datagen = ImageDataGenerator(
    preprocessing_function=preprocess_input, # MobileNet specific scaling (-1 to 1)
    validation_split=0.2,
    rotation_range=20,       # Rotate images slightly
    width_shift_range=0.2,   # Shift left/right
    height_shift_range=0.2,  # Shift up/down
    shear_range=0.2,         # Shear
    zoom_range=0.2,          # Zoom in/out
    horizontal_flip=True,    # Flip left/right
    fill_mode='nearest'
)

# Validation data should NOT be augmented, just preprocessed
val_datagen = ImageDataGenerator(
    preprocessing_function=preprocess_input,
    validation_split=0.2
)

print("Loading Training Data (with Augmentation)...")
train_gen = train_datagen.flow_from_directory(
    DATASET_DIR,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical',
    subset='training',
    shuffle=True
)

print("Loading Validation Data...")
val_gen = val_datagen.flow_from_directory(
    DATASET_DIR,
    target_size=IMG_SIZE,
    batch_size=BATCH_SIZE,
    class_mode='categorical',
    subset='validation'
)

num_classes = train_gen.num_classes
class_names = list(train_gen.class_indices.keys())
print(f"✅ Detected {num_classes} classes: {class_names}")

# --- 2. Transfer Learning Architecture (MobileNetV2) ---
# Load the pre-trained base model (without the top classification layer)
base_model = MobileNetV2(
    input_shape=IMG_SIZE + (3,), 
    include_top=False, 
    weights='imagenet'
)

# Freeze the base model so we don't destroy the pre-learned patterns
base_model.trainable = False

# Add our custom layers on top
x = base_model.output
x = GlobalAveragePooling2D()(x) # Condenses features better than Flatten
x = Dense(128, activation='relu')(x)
x = Dropout(0.5)(x) # Prevents overfitting on small data
predictions = Dense(num_classes, activation='softmax')(x)

# Create the final model
model = Model(inputs=base_model.input, outputs=predictions)

# --- 3. Compile & Train ---
model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.0001), 
              loss='categorical_crossentropy', 
              metrics=['accuracy'])

print("🚀 Starting Training with Transfer Learning...")
# Increased epochs slightly because the learning rate is lower for stability
history = model.fit(train_gen, validation_data=val_gen, epochs=20) 

# --- 4. Fine-Tuning (Optional but recommended) ---
# Unfreeze the last few layers of the base model to adapt slightly to your data
print("🔧 Fine-tuning model...")
base_model.trainable = True
# Freeze all layers except the last 20
for layer in base_model.layers[:-20]:
    layer.trainable = False

model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=0.00001), # Very low LR
              loss='categorical_crossentropy',
              metrics=['accuracy'])

model.fit(train_gen, validation_data=val_gen, epochs=5)

# --- Save ---
model.save("activity_multiclass_model.h5")

with open("class_names.txt", "w") as f:
    f.write("\n".join(class_names))

print("✅ Model saved as 'activity_multiclass_model.h5'")
print("✅ Class names saved to 'class_names.txt'")